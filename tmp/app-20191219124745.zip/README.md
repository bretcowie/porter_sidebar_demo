# App name

This is a demo app that was built to show Porter Airlines how the app can pull field totals, sum them, and use the values to display an approval threshold that can help with choosing a macro to apply to the ticket for next action.

### The following information is displayed:

* info1
* info2
* info3

Please submit bug reports to [Insert Link](). Pull requests are welcome.

### Screenshot(s):
[put your screenshots down here.]
